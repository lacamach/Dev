﻿using Microsoft.PowerBI.Api.Extensions;
using Microsoft.PowerBI.Api.Models;
using Microsoft.PowerBI.Api.Models.Credentials;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Token
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        public void GeneraToken()
        {

            Microsoft.PowerBI.Api.Models.GatewayPublicKey publicKey = new GatewayPublicKey();
            publicKey.Exponent = txtExponent.Text;
            publicKey.Modulus = txtModulus.Text;

                // Basic credentials
            var credentials = new BasicCredentials(username: txtUsuario.Text, password: txtPass.Text);

            var credentialsEncryptor = new AsymmetricKeyEncryptor(publicKey);
            var credentialDetails = new CredentialDetails(credentials, PrivacyLevel.Private, EncryptedConnection.Encrypted, credentialsEncryptor);
            txtCredenciales.Text =  credentialDetails.Credentials.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            GeneraToken();
            txtCredenciales.ReadOnly = false;
        }
    }

}
